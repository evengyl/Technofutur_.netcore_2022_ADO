﻿CREATE TABLE [dbo].[Section] (
    [Id]          INT          NOT NULL,
    [SectionName] VARCHAR (50) NOT NULL,
    CONSTRAINT [PK_Section] PRIMARY KEY CLUSTERED ([Id] ASC)
);
